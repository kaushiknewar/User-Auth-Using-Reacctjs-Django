export function getUserToken(state) {
    return state.auth.token;
}