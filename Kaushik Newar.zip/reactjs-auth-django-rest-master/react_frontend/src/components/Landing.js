import React from "react";

const Landing = () => (
    <h1>Welcome to this wonderful site.</h1>
);

export default Landing;
